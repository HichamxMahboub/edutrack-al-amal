<?php

namespace Database\Seeders;

use App\Enums\UserRole;
use App\Models\Grade;
use App\Models\Message;
use App\Models\SchoolClass;
use App\Models\Student;
use App\Models\Subject;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Arr;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $admin = User::factory()->create([
            'name' => 'Admin EduTrack',
            'email' => 'admin@edutrack.test',
            'role' => UserRole::Admin,
            'phone' => '0600000001',
            'specialty' => 'Direction',
        ]);

        $teacher = User::factory()->create([
            'name' => 'Enseignant Démo',
            'email' => 'enseignant@edutrack.test',
            'role' => UserRole::Enseignant,
            'phone' => '0600000002',
            'specialty' => 'Mathématiques',
        ]);

        $mentor = User::factory()->create([
            'name' => 'Encadrant Démo',
            'email' => 'encadrant@edutrack.test',
            'role' => UserRole::Encadrant,
            'phone' => '0600000003',
            'specialty' => 'Accompagnement social',
        ]);

        $teachers = User::factory(3)->create([
            'role' => UserRole::Enseignant,
        ]);

        $mentors = User::factory(2)->create([
            'role' => UserRole::Encadrant,
        ]);

        $allTeachers = $teachers->push($teacher);
        $allStaff = $allTeachers->concat($mentors)->push($admin);

        $subjects = collect([
            ['name' => 'Mathématiques', 'code' => 'MATH', 'default_coefficient' => 2],
            ['name' => 'Français', 'code' => 'FR', 'default_coefficient' => 2],
            ['name' => 'Sciences', 'code' => 'SCI', 'default_coefficient' => 1.5],
            ['name' => 'Histoire-Géographie', 'code' => 'HG', 'default_coefficient' => 1],
            ['name' => 'Anglais', 'code' => 'ANG', 'default_coefficient' => 1.5],
            ['name' => 'Informatique', 'code' => 'INFO', 'default_coefficient' => 1],
        ])->map(fn (array $data) => Subject::create($data));

        $classes = collect([
            ['name' => 'Classe A1', 'level' => 'Collège', 'school_year' => '2025-2026'],
            ['name' => 'Classe B2', 'level' => 'Collège', 'school_year' => '2025-2026'],
            ['name' => 'Classe C3', 'level' => 'Lycée', 'school_year' => '2025-2026'],
            ['name' => 'Classe D4', 'level' => 'Lycée', 'school_year' => '2025-2026'],
        ])->map(function (array $data) use ($allTeachers) {
            return SchoolClass::create([
                ...$data,
                'description' => 'Classe pilote EduTrack Al Amal',
                'teacher_id' => $allTeachers->random()->id,
            ]);
        });

        $students = Student::factory(32)->make()->each(function (Student $student) use ($classes) {
            $student->school_class_id = $classes->random()->id;
            $student->save();
        });

        $students = Student::all();

        foreach ($students as $student) {
            foreach ($subjects as $subject) {
                Grade::create([
                    'student_id' => $student->id,
                    'subject_id' => $subject->id,
                    'teacher_id' => $allTeachers->random()->id,
                    'score' => Arr::random([8.5, 10.5, 12.0, 13.5, 15.0, 16.5, 18.0]),
                    'coefficient' => $subject->default_coefficient,
                    'semester' => Arr::random(['S1', 'S2']),
                    'observation' => Arr::random([
                        'Bonne progression.',
                        'Doit participer davantage.',
                        'Excellent travail.',
                        'Résultats stables.',
                        'Peut mieux faire.',
                    ]),
                ]);
            }
        }

        Message::factory(12)->make()->each(function (Message $message) use ($allStaff) {
            $sender = $allStaff->random();
            $recipient = $allStaff->where('id', '!=', $sender->id)->random();

            $message->sender_id = $sender->id;
            $message->recipient_id = $recipient->id;
            $message->save();
        });
    }
}
