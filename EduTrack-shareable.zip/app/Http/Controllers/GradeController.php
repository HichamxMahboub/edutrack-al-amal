<?php

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Models\Grade;
use App\Models\SchoolClass;
use App\Models\Student;
use App\Models\Subject;
use App\Models\User;
use Illuminate\Http\Request;

class GradeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $user = $request->user();
        $query = Grade::with(['student.schoolClass', 'subject', 'teacher']);

        if ($user->isTeacher()) {
            $query->where('teacher_id', $user->id);
        }

        if ($studentId = $request->input('student_id')) {
            $query->where('student_id', $studentId);
        }

        if ($subjectId = $request->input('subject_id')) {
            $query->where('subject_id', $subjectId);
        }

        if ($semester = $request->string('semester')->trim()->toString()) {
            $query->where('semester', $semester);
        }

        if ($classId = $request->input('class_id')) {
            $query->whereHas('student', fn ($builder) => $builder->where('school_class_id', $classId));
        }

        $grades = $query->latest()->paginate(10)->withQueryString();

        $classes = SchoolClass::orderBy('name')->get();
        $studentsQuery = Student::orderBy('last_name');

        if ($user->isTeacher()) {
            $classIds = SchoolClass::where('teacher_id', $user->id)->pluck('id');
            $studentsQuery->whereIn('school_class_id', $classIds);
        }

        $students = $studentsQuery->get();
        $subjects = Subject::orderBy('name')->get();

        return view('grades.index', compact('grades', 'classes', 'students', 'subjects'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $user = auth()->user();
        $classes = SchoolClass::orderBy('name')->get();

        $studentsQuery = Student::orderBy('last_name');
        if ($user->isTeacher()) {
            $classIds = SchoolClass::where('teacher_id', $user->id)->pluck('id');
            $studentsQuery->whereIn('school_class_id', $classIds);
        }

        $students = $studentsQuery->get();
        $subjects = Subject::orderBy('name')->get();
        $teachers = User::where('role', UserRole::Enseignant->value)->orderBy('name')->get();

        return view('grades.create', compact('students', 'subjects', 'classes', 'teachers'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'student_id' => 'required|exists:students,id',
            'subject_id' => 'required|exists:subjects,id',
            'score' => 'required|numeric|min:0|max:20',
            'coefficient' => 'required|numeric|min:0.5|max:10',
            'semester' => 'required|string|max:10',
            'observation' => 'nullable|string',
            'teacher_id' => 'nullable|exists:users,id',
        ]);

        $user = $request->user();
        $validated['teacher_id'] = $user->isTeacher() ? $user->id : ($validated['teacher_id'] ?? null);

        $grade = Grade::create($validated);

        return redirect()->route('grades.show', $grade)->with('success', 'Note enregistrée.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Grade $grade)
    {
        $grade->load(['student.schoolClass', 'subject', 'teacher']);

        return view('grades.show', compact('grade'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Grade $grade)
    {
        $user = auth()->user();

        if ($user->isTeacher() && $grade->teacher_id !== $user->id) {
            abort(403);
        }

        $students = Student::orderBy('last_name')->get();
        $subjects = Subject::orderBy('name')->get();
        $teachers = User::where('role', UserRole::Enseignant->value)->orderBy('name')->get();

        return view('grades.edit', compact('grade', 'students', 'subjects', 'teachers'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Grade $grade)
    {
        $user = $request->user();

        if ($user->isTeacher() && $grade->teacher_id !== $user->id) {
            abort(403);
        }

        $validated = $request->validate([
            'student_id' => 'required|exists:students,id',
            'subject_id' => 'required|exists:subjects,id',
            'score' => 'required|numeric|min:0|max:20',
            'coefficient' => 'required|numeric|min:0.5|max:10',
            'semester' => 'required|string|max:10',
            'observation' => 'nullable|string',
            'teacher_id' => 'nullable|exists:users,id',
        ]);

        if ($user->isTeacher()) {
            $validated['teacher_id'] = $user->id;
        }

        $grade->update($validated);

        return redirect()->route('grades.show', $grade)->with('success', 'Note mise à jour.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Grade $grade)
    {
        $user = auth()->user();

        if ($user->isTeacher() && $grade->teacher_id !== $user->id) {
            abort(403);
        }

        $grade->delete();

        return redirect()->route('grades.index')->with('success', 'Note supprimée.');
    }
}
