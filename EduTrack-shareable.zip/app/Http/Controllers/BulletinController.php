<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Barryvdh\DomPDF\Facade\Pdf;

class BulletinController extends Controller
{
    public function show(Student $student)
    {
        $student->load(['schoolClass', 'grades.subject', 'grades.teacher']);

        return view('bulletins.show', [
            'student' => $student,
            'average' => $student->averageScore(),
            'mention' => $student->mention(),
        ]);
    }

    public function pdf(Student $student)
    {
        $student->load(['schoolClass', 'grades.subject', 'grades.teacher']);

        $pdf = Pdf::loadView('bulletins.pdf', [
            'student' => $student,
            'average' => $student->averageScore(),
            'mention' => $student->mention(),
        ])->setPaper('a4');

        return $pdf->download('bulletin-'.$student->id.'.pdf');
    }
}
