<?php

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Models\SchoolClass;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $role = $request->string('role')->trim()->toString();

        $query = User::query()->whereIn('role', [UserRole::Enseignant->value, UserRole::Encadrant->value]);

        if ($role) {
            $query->where('role', $role);
        }

        $staff = $query->orderBy('name')->paginate(10)->withQueryString();

        return view('staff.index', compact('staff', 'role'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $classes = SchoolClass::orderBy('name')->get();
        $roles = [
            UserRole::Enseignant->value => UserRole::Enseignant->label(),
            UserRole::Encadrant->value => UserRole::Encadrant->label(),
        ];

        return view('staff.create', compact('classes', 'roles'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'role' => 'required|in:enseignant,encadrant',
            'phone' => 'nullable|string|max:50',
            'specialty' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:8',
            'class_ids' => 'nullable|array',
            'class_ids.*' => 'exists:school_classes,id',
        ]);

        $password = $validated['password'] ?? 'password';

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'role' => $validated['role'],
            'phone' => $validated['phone'] ?? null,
            'specialty' => $validated['specialty'] ?? null,
            'password' => Hash::make($password),
        ]);

        if ($validated['role'] === UserRole::Enseignant->value) {
            SchoolClass::whereIn('id', $validated['class_ids'] ?? [])->update([
                'teacher_id' => $user->id,
            ]);
        }

        return redirect()->route('staff.show', $user)->with('success', 'Membre ajouté.');
    }

    /**
     * Display the specified resource.
     */
    public function show(User $staff)
    {
        $staff->load('schoolClasses');

        return view('staff.show', ['staffMember' => $staff]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $staff)
    {
        $classes = SchoolClass::orderBy('name')->get();
        $roles = [
            UserRole::Enseignant->value => UserRole::Enseignant->label(),
            UserRole::Encadrant->value => UserRole::Encadrant->label(),
        ];

        return view('staff.edit', [
            'staffMember' => $staff,
            'classes' => $classes,
            'roles' => $roles,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $staff)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,'.$staff->id,
            'role' => 'required|in:enseignant,encadrant',
            'phone' => 'nullable|string|max:50',
            'specialty' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:8',
            'class_ids' => 'nullable|array',
            'class_ids.*' => 'exists:school_classes,id',
        ]);

        $staff->update([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'role' => $validated['role'],
            'phone' => $validated['phone'] ?? null,
            'specialty' => $validated['specialty'] ?? null,
        ]);

        if (!empty($validated['password'])) {
            $staff->update(['password' => Hash::make($validated['password'])]);
        }

        if ($validated['role'] === UserRole::Enseignant->value) {
            $classIds = $validated['class_ids'] ?? [];

            SchoolClass::where('teacher_id', $staff->id)
                ->whereNotIn('id', $classIds)
                ->update(['teacher_id' => null]);

            SchoolClass::whereIn('id', $classIds)->update(['teacher_id' => $staff->id]);
        } else {
            SchoolClass::where('teacher_id', $staff->id)->update(['teacher_id' => null]);
        }

        return redirect()->route('staff.show', $staff)->with('success', 'Membre mis à jour.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $staff)
    {
        if ($staff->isAdmin()) {
            return redirect()->route('staff.index')->with('error', 'Impossible de supprimer un administrateur.');
        }

        SchoolClass::where('teacher_id', $staff->id)->update(['teacher_id' => null]);
        $staff->delete();

        return redirect()->route('staff.index')->with('success', 'Membre supprimé.');
    }
}
