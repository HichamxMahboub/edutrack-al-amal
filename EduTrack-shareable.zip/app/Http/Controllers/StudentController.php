<?php

namespace App\Http\Controllers;

use App\Models\SchoolClass;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $user = $request->user();
        $query = Student::query()->with('schoolClass');

        if ($user->isTeacher()) {
            $classIds = SchoolClass::where('teacher_id', $user->id)->pluck('id');
            $query->whereIn('school_class_id', $classIds);
        }

        if ($search = $request->string('search')->trim()->toString()) {
            $query->where(function ($builder) use ($search) {
                $builder->where('first_name', 'like', "%{$search}%")
                    ->orWhere('last_name', 'like', "%{$search}%");
            });
        }

        if ($status = $request->string('status')->trim()->toString()) {
            $query->where('status', $status);
        }

        if ($classId = $request->input('class_id')) {
            $query->where('school_class_id', $classId);
        }

        $students = $query->orderBy('last_name')->paginate(10)->withQueryString();
        $classes = SchoolClass::orderBy('name')->get();

        return view('students.index', compact('students', 'classes'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $classes = SchoolClass::orderBy('name')->get();

        return view('students.create', compact('classes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'date_of_birth' => 'nullable|date',
            'gender' => 'required|in:Masculin,Féminin',
            'school_class_id' => 'nullable|exists:school_classes,id',
            'parent_phone' => 'nullable|string|max:50',
            'address' => 'nullable|string|max:255',
            'social_status' => 'nullable|string',
            'medical_notes' => 'nullable|string',
            'status' => 'required|in:actif,archivé',
            'photo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('photo')) {
            $validated['photo_path'] = $request->file('photo')->store('students', 'public');
        }

        Student::create($validated);

        return redirect()->route('students.index')->with('success', 'Élève créé avec succès.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Student $student)
    {
        $student->load(['schoolClass', 'grades.subject', 'grades.teacher']);

        return view('students.show', compact('student'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Student $student)
    {
        $classes = SchoolClass::orderBy('name')->get();

        return view('students.edit', compact('student', 'classes'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Student $student)
    {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'date_of_birth' => 'nullable|date',
            'gender' => 'required|in:Masculin,Féminin',
            'school_class_id' => 'nullable|exists:school_classes,id',
            'parent_phone' => 'nullable|string|max:50',
            'address' => 'nullable|string|max:255',
            'social_status' => 'nullable|string',
            'medical_notes' => 'nullable|string',
            'status' => 'required|in:actif,archivé',
            'photo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('photo')) {
            if ($student->photo_path) {
                Storage::disk('public')->delete($student->photo_path);
            }
            $validated['photo_path'] = $request->file('photo')->store('students', 'public');
        }

        $student->update($validated);

        return redirect()->route('students.show', $student)->with('success', 'Élève mis à jour.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Student $student)
    {
        $student->update([
            'status' => 'archivé',
            'archived_at' => now(),
        ]);

        return redirect()->route('students.index')->with('success', 'Élève archivé.');
    }
}
